from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
import psycopg2
from hello import log_stream
from login import login
from api_routes import api_routes
from windows_app import start_service_windows_route, stop_service_windows_route, restart_service_windows_route
from linux_app import start_service_linux_route, stop_service_linux_route, restart_service_linux_route
from windows_app import windows_app
from linux_app import linux_app
from __int__ import your_blueprint_name, submit

app = Flask(__name__)
# FORM
app.register_blueprint(your_blueprint_name)
app.route('/api/submit', methods=['POST'])(submit)
# WINDOWS
app.route('/automation/api/1.0/windows/start_service', methods=['POST'])(start_service_windows_route)
app.route('/automation/api/1.0/windows/stop_service', methods=['POST'])(stop_service_windows_route)
app.route('/automation/api/1.0/windows/restart_service', methods=['POST'])(restart_service_windows_route)

# LINUX
app.route('/automation/api/1.0/linux/start_service', methods=['POST'])(start_service_linux_route)
app.route('/automation/api/1.0/linux/stop_service', methods=['POST'])(stop_service_linux_route)
app.route('/automation/api/1.0/linux/restart_service', methods=['POST'])(restart_service_linux_route)

# stream
app.route('/log_stream', methods=['GET'])(log_stream)

# login
app.route('/api/login', methods=['POST'])(login)

app.register_blueprint(api_routes)
app.register_blueprint(windows_app)
app.register_blueprint(linux_app)

# database connection
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:1234@localhost/christal'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)


class Service(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    service_name = db.Column(db.String(255), nullable=False)


@app.route("/api/View_Service", methods=["GET", "POST"])
def view_services():
    if request.method == "GET":
        try:
            services = Service.query.all()
            services_list = [{"id": service.id, "service_name": service.service_name} for service in services]
            return jsonify({"services": services_list})
        except Exception as e:
            app.logger.error(f"Error in view all services operation: {str(e)}")
            return jsonify({"message": "Internal Server Error", "error": str(e)}), 500
    elif request.method == "POST":
        try:
            if request.headers.get('Content-Type') != 'application/json':
                return jsonify({"error": "415 Unsupported Media Type: Request must be in JSON format.",
                                "message": "Internal Server Error"}), 415

            data = request
            new_service_name = data.get("service_name")

            if not new_service_name:
                return jsonify({"message": "Service name is required"}), 400

            new_service = Service(service_name=new_service_name)
            db.session.add(new_service)
            db.session.commit()

            return jsonify({"message": "Service added successfully"})
        except Exception as e:
            app.logger.error(f"Error in adding a new service: {str(e)}")
            return jsonify({"message": "Internal Server Error", "error": str(e)}), 500


@app.route('/api/log_stream', methods=['GET', 'OPTIONS'])
def add_service():
    try:
        if request.headers.get('Content-Type') != 'application/json':
            return jsonify({"error": "415 Unsupported Media Type: Request must be in JSON format.",
                            "message": "Internal Server Error"}), 415

        data = request
        new_service_name = data.get("service_name")

        if not new_service_name:
            return jsonify({"message": "Service name is required"}), 400

        new_service = Service(service_name=new_service_name)
        db.session.add(new_service)
        db.session.commit()

        return jsonify({"message": "Service added successfully"})
    except Exception as e:
        app.logger.error(f"Error in adding a new service: {str(e)}")
        return jsonify({"message": "Internal Server Error", "error": str(e)}), 500


@app.route("/api/Update_Service/<int:service_id>", methods=["PUT"])
def update_service(service_id):
    try:
        if request.headers.get('Content-Type') != 'application/json':
            return jsonify({"error": "415 Unsupported Media Type: Request must be in JSON format.",
                            "message": "Internal Server Error"}), 415

        data = request
        updated_service_name = data.get("service_name")

        if not updated_service_name:
            return jsonify({"message": "Updated service name is required"}), 400

        service = Service.query.get(service_id)

        if not service:
            return jsonify({"message": "Service not found"}), 404

        service.service_name = updated_service_name
        db.session.commit()

        return jsonify({"message": "Service updated successfully"})
    except Exception as e:
        app.logger.error(f"Error in updating service: {str(e)}")
        return jsonify({"message": "Internal Server Error", "error": str(e)}), 500


@app.route("/api/Delete_Service/<int:service_id>", methods=["DELETE"])
def delete_service(service_id):
    try:
        service = Service.query.get(service_id)

        if not service:
            return jsonify({"message": "Service not found"}), 404

        db.session.delete(service)
        db.session.commit()

        return jsonify({"message": "Service deleted successfully"})
    except Exception as e:
        app.logger.error(f"Error in deleting service: {str(e)}")
        return jsonify({"message": "Internal Server Error", "error": str(e)}), 500


b_params = {
    'host': 'localhost',
    'database': 'christal',
    'user': 'postgres',
    'password': '1234',
    'port': '5432'
}


@app.route('/api/resource/<int:id>', methods=['GET'])
def get_resource_by_id(id):
    conn = None
    try:
        conn = psycopg2.connect(**b_params)
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM service WHERE id = %s', (id,))
        result = cursor.fetchone()

        if result:
            response = {"id": result[0], "value": result[1]}
            return jsonify(response)
        else:
            return jsonify({"error": "Resource not found"}), 404
    except Exception as e:
        app.logger.error(f"Error in getting a resource by ID: {str(e)}")
        return jsonify({"message": "Internal Server Error", "error": str(e)}), 500
    finally:
        if conn:
            conn.close()


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    CORS(app)
    app.run(debug=True, host='0.0.0.0')
