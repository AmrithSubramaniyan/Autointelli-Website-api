from flask import Flask, jsonify, request, Blueprint
from pypsrp.client import Client as PSRPClient

windows_app = Blueprint('windows_app', __name__)

app = Flask(__name__)

common_username = ""
common_password = ""

windows_hostname = "localhost"
windows_port = 5985


def execute_powershell_command(command):
    client = None
    try:
        client = PSRPClient(
            server=windows_hostname,
            port=windows_port,
            username=common_username,
            password=common_password,
            ssl=False,
            auth="ntlm",
            timeout=60,
        )

        result = client.execute_ps(command)
        return {
            "status": "success",
            "result": result[0].strip(),
        }

    except Exception as e:
        return {
            "status": "error",
            "error_message": str(e),
        }

    finally:
        if client:
            client.close()


# start-service
@app.route('/automation/api/1.0/windows/start_service', methods=['POST'])
def start_service_windows_route():
    try:
        data = request
        service_name = data.get('service_name')

        command = f'Start-Service -Name "{service_name}"'
        command_result = execute_powershell_command(command)

        return jsonify({'Status': 'Success', 'Message': f"Service '{service_name}' started successfully"})

    except Exception as e:
        return jsonify({'Status': 'Failure', 'Message': f"Failed to start service: {str(e)}"}), 500


# stop-service
@app.route('/automation/api/1.0/windows/stop_service', methods=['POST'])
def stop_service_windows_route():
    try:
        data = request
        service_name = data.get('service_name')

        command = f'Stop-Service -Name "{service_name}"'
        command_result = execute_powershell_command(command)

        return jsonify({'Status': 'Success', 'Message': f"Service '{service_name}' stopped successfully"})

    except Exception as e:
        return jsonify({'Status': 'Failure', 'Message': f"Failed to stop service: {str(e)}"}), 500


# Restart-Service
@app.route('/automation/api/1.0/windows/restart_service', methods=['POST'])
def restart_service_windows_route():
    try:
        data = request
        service_name = data.get('service_name')

        command_stop = f'Stop-Service -Name "{service_name}"'
        command_start = f'Start-Service -Name "{service_name}"'

        # Stop the service
        execute_powershell_command(command_stop)

        # Start the service
        execute_powershell_command(command_start)

        return jsonify({'Status': 'Success', 'Message': f"Service '{service_name}' restarted successfully"})

    except Exception as e:
        return jsonify({'Status': 'Failure', 'Message': f"Failed to restart service: {str(e)}"}), 500


