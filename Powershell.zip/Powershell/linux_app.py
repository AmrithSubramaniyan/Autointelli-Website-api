from flask import Flask, jsonify, request, Blueprint
import paramiko

linux_app = Blueprint('linux_app', __name__)

app = Flask(__name__)

common_username = "root"
common_password = "@ut0!ntell!@123"

linux_hostname = "dev.autointelli.com"
linux_port = 20222


def execute_bash_command(command):
    try:
        sshclient = paramiko.SSHClient()
        sshclient.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        sshclient.connect(
            linux_hostname,
            port=linux_port,
            username=common_username,
            password=common_password,
            look_for_keys=False,
            allow_agent=False,
            timeout=60
        )

        result = sshclient.exec_command(command)
        return {
            "status": "success",
            "result": result[1].read().decode("utf-8").strip(),
        }

    except Exception as e:
        return {
            "status": "error",
            "error_message": str(e),
        }

    finally:
        sshclient.close()


# start-service
@app.route('/automation/api/1.0/linux/start_service', methods=['POST'])
def start_service_linux_route():
    try:
        data = request
        service_name = data.get('service_name')

        command = f'systemctl start {service_name}'
        execute_bash_command(command)

        return jsonify({'status': 'success', 'message': f"Service '{service_name}' started successfully"})

    except Exception as e:
        return jsonify({'status': 'error', 'message': f"Failed to start service: {str(e)}"}), 500


# stop-service
@app.route('/automation/api/1.0/linux/stop_service', methods=['POST'])
def stop_service_linux_route():
    try:
        data = request
        service_name = data.get('service_name')

        command = f'systemctl stop {service_name}'
        execute_bash_command(command)

        return jsonify({'status': 'success', 'message': f"Service '{service_name}' stopped successfully"})

    except Exception as e:
        return jsonify({'status': 'error', 'message': f"Failed to stop service: {str(e)}"}), 500


# Restart-Service
@app.route('/automation/api/1.0/linux/restart_service', methods=['POST'])
def restart_service_linux_route():
    try:
        data = request
        service_name = data.get('service_name')

        command = f'systemctl restart {service_name}'
        execute_bash_command(command)

        return jsonify({'status': 'success', 'message': f"Service '{service_name}' restarted successfully"})

    except Exception as e:
        return jsonify({'status': 'error', 'message': f"Failed to restart service: {str(e)}"}), 500


