from flask import Blueprint, request, jsonify

api_routes = Blueprint('api_routes', __name__)


@api_routes.route('/Start-api', methods=['POST'])
def start_api():
    try:
        form_data = request.json
        server_ip = form_data.get('Server IP ')
        server_password = form_data.get('Server Password')
        service_name = form_data.get('Service Name')

        return jsonify({'message': 'API started successfully'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@api_routes.route('/Stop-api', methods=['POST'])
def stop_api():
    try:
        form_data = request.json
        server_ip = form_data.get('Server IP')
        server_password = form_data.get('Server Password')
        service_name = form_data.get('Service Name')

        return jsonify({'message': 'API stop successfully'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@api_routes.route('/Reboot-api', methods=['POST'])
def reboot_api():
    try:
        form_data = request.json
        server_ip = form_data.get('Server IP')
        server_password = form_data.get('Server Password')
        service_name = form_data.get('Service Name')

        return jsonify({'message': 'API reboot successfully'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@api_routes.route('/Restart-api', methods=['POST'])
def restart_api():
    try:
        form_data = request.json
        server_ip = form_data.get('Server IP')
        server_password = form_data.get('Server Password')
        service_name = form_data.get('Service Name')

        return jsonify({'message': 'API restart successfully'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500
