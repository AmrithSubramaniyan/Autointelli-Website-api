from flask import Flask, jsonify, Blueprint, request
from flask_restful import Api, Resource
import requests

app = Flask(__name__)
api = Api(app)

your_blueprint_name = Blueprint('your_blueprint_name', __name__)

form_fields = [
    {"field_name": "Server IP", "field_type": "TEXT"},
    {"field_name": "Server Port", "field_type": "INT"},
    {"field_name": "Server User", "field_type": "TEXT"},
    {"field_name": "Server Password", "field_type": "PASSWORD"},
    {"field_name": "Service Name", "field_type": "SELECT", "field_data": ["W32Time", "W3SVC", "WWW"]},
]


class FormApi(Resource):
    def get(self):
        return jsonify(form_fields)

    def post(self):
        success_condition = True

        if success_condition:
            return jsonify({'success': 'True', 'message': 'Form data received successfully'})
        else:
            return jsonify({'success': 'False', 'message': 'Form data processing failed'})


api.add_resource(FormApi, '/api/form', endpoint='form_api', methods=['GET', 'POST'])
your_blueprint_name.add_url_rule('/api/form', view_func=FormApi.as_view('form_api'))
app.register_blueprint(your_blueprint_name)


@app.route('/api/submit', methods=['POST'])
def submit():
    try:
        data = request.json

        response = requests.post('http://127.0.0.1:5000/api/form', json=data)

        if response.json()['success'] == "True":
            app.logger.info(f"Form submit successful: {data}")
            return jsonify({'success': True, 'message': 'Form submit successful'}), 200
        else:
            app.logger.warning(f"Form submit failed: {data}")
            return jsonify({'success': False, 'message': 'Form submit failed'}), 401
    except Exception as e:
        app.logger.error(f"Exception during form submission: {str(e)}")
        return jsonify({'success': False, 'message': 'Internal Server Error'}), 500





if __name__ == '__main__':
    app.run(debug=True)
