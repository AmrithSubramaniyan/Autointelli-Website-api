from flask import Flask, jsonify, request, Blueprint

app = Flask(__name__)

login = Blueprint('login', __name__)


# LOGIN
@app.route('/api/login', methods=['POST'])
def login():
    try:
        data = request.json
        username = data.get('username')
        password = data.get('password')

        if username == '1234' and password == 'abcd':

            app.logger.info(f"Login successful for user: {username}")
            return jsonify({'success': True, 'message': 'Login successful'}), 200
        else:

            app.logger.warning(f"Login failed for user: {username}")
            return jsonify({'success': False, 'message': 'Login failed'}), 401
    except Exception as e:
        app.logger.error(f"Error during login: {str(e)}")
        return jsonify({'success': False, 'message': 'Internal Server Error'}), 500
