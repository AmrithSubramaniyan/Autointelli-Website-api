from flask import Flask, Response, Blueprint
from flask_cors import CORS
import time
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import json

app = Flask(__name__)
CORS(app)
hello = Blueprint('hello', __name__)

log_path = "C:\\windows\\temp\\test.log"  # Provide the actual log path


class LogFileHandler(FileSystemEventHandler):
    def on_modified(self, event):
        if event.src_path == log_path:
            app.logger.info("Log file modified.")


@app.route('/api/log_stream', methods=['GET', 'OPTIONS'])
def log_stream():
    def generate_logs():
        with open(log_path, 'r') as file:
            where = file.tell()
            yield "data: " + json.dumps({"data": file.read()}) + "\n\n"
            while True:
                line = file.readline()
                if not line:
                    time.sleep(0.5)
                    file.seek(where)
                else:
                    where = file.tell()
                    yield "data: " + json.dumps({"data": line}) + "\n\n"

    event_handler = LogFileHandler()
    observer = Observer()
    observer.schedule(event_handler, path=".", recursive=False)
    observer.start()

    try:
        return Response(generate_logs(), content_type='text/event-stream')
    finally:
        observer.stop()
        observer.join()


if __name__ == '__main__':
    app.run(debug=True)
