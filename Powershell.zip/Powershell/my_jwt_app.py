from flask import Flask, jsonify, request
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity, set_access_cookies
from datetime import timedelta

app = Flask(__name__)

jwt = JWTManager(app)
app.config['JWT_TOKEN_LOCATION'] = ['cookies']
app.config['JWT_GENERATE_TOKEN'] = timedelta(seconds=60)
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=1)
app.config['JWT_SECRET_KEY'] = 'your-secret-key'
# create jwt manger

jwt = JWTManager(app)


@app.route('/login', methods=['POST'])
def login():
    username = request.json.get('username', None)
    password = request.json.get('password', None)

    if username == 'Christal' and password == 'Christal@4':
        access_token = create_access_token(identity=username)
        response = jsonify({'login': True})
        set_access_cookies(response, access_token)  # Import set_access_cookies
        return response, 200
    else:
        return jsonify({'login': False}), 401


# Example protected route
@app.route('/protected', methods=['GET'])
@jwt_required()
def protected():
    current_user = get_jwt_identity()
    return jsonify(logged_in_as=current_user), 200


if __name__ == '__main__':
    app.run(debug=True)
